# Guia do patch do Gofoot (para criar ou editar com IA)

Um patch é uma pasta com arquivos JSON e imagens PNG. Dá para gerar tudo com qualquer IA (ChatGPT, Claude, Gemini) e colar na pasta do patch.

## Regras

- **Só definição.** O patch descreve o começo do jogo. Gols, jogos, energia, lesões e históricos são da carreira e são ignorados.
- **OVER, valor e salário são calculados** a partir dos atributos. Não precisa escrevê-los.
- **Ids** usam letras minúsculas, números, `_` ou `-`, sem espaço nem acento, e não se repetem.
- **Ligas nacionais, a copa e a supercopa nacional são automáticas:** basta o país (`division_sizes`) e os clubes com `elo`. O clube mais forte vai para a primeira divisão. A supercopa (campeão da copa × campeão da liga) começa na 2ª temporada; para jogar já na 1ª, inscreva os 2 clubes nela.
- **Temporada inicial:** 2026.

## Arquivos e campos

### `data/countries.json`

Países. Para cada país o jogo monta sozinho as divisões nacionais (com acesso e rebaixamento) e a copa nacional, pelo Elo dos clubes.

Formato: `{ "countries": [ ... ] }`.

| Campo | Tipo | Obrigatório | Valores |
|---|---|---|---|
| `id` | texto | sim | Identificador do país (letras minúsculas, números, _ ou -) |
| `name` | texto | sim | Nome do país |
| `iso2` | texto | sim | Código da nacionalidade que dá a bandeira (ex.: br) |
| `confederation` | texto | sim | Confederação. `CONMEBOL`, `UEFA`, `CAF`, `AFC`, `CONCACAF`, `OFC` |
| `division_sizes` | lista | não | Clubes em cada divisão nacional, de 1 a 8 divisões, cada uma com 2 a 256 clubes. Padrão: 4 divisões de 20 |
| `supercup` | sim/não | não | Supercopa nacional (campeão da copa × campeão da liga, no início da temporada). Padrão: true |

### `data/clubs/{id}.json`

Um arquivo por clube: os dados do clube, o elenco (jogadores), as categorias de base (juniores) e o técnico.

| Campo | Tipo | Obrigatório | Valores |
|---|---|---|---|
| `id` | texto | sim | Identificador do clube; o arquivo tem o mesmo nome. O escudo é images/clubs/{id}.png |
| `nome` | texto | sim | Nome do clube |
| `country_id` | texto | sim | Id do país em countries.json |
| `estado` | texto | não | Estado/UF (só para clubes do Brasil) |
| `corPrimaria` | texto | não | Cor principal em hexadecimal (#rrggbb) |
| `corSecundaria` | texto | não | Cor secundária em hexadecimal (#rrggbb) |
| `reputacao` | número | não | Reputação do clube. 0 a 100 |
| `elo` | número | não | Força inicial; decide a divisão e os potes da copa. 0 a 1000 |
| `stadium_id` | texto | não | Id do estádio em stadiums.json |
| `rival_ids` | lista | não | Ids dos clubes rivais |
| `jogadores` | lista | sim | Elenco: lista de jogadores (até 35), campos abaixo |
| `juniores` | lista | não | Juniores, campos abaixo |
| `tecnico` | objeto | não | O técnico do clube, campos de coaches.json |

### `data/clubs/{id}.json → jogadores[]`

Cada jogador do elenco. Use os atributos da função dele (goleiro: REF, POS, AER, SAI e MEN; os demais: TEC, ATA, DEF, FIS e MEN); OVER, valor e salário são calculados.

| Campo | Tipo | Obrigatório | Valores |
|---|---|---|---|
| `id` | texto | não | Identificador único; sem ele, o jogo usa {id do clube}_{posição na lista} |
| `nome` | texto | sim | Nome do jogador |
| `posicao` | texto | sim | Posição: G (goleiro), Z (zagueiro), LE/LD (lateral), V (volante), M (meia), PE/PD (ponta), CA (centroavante). `G`, `Z`, `LE`, `LD`, `V`, `M`, `PE`, `PD`, `CA` |
| `idade` | número inteiro | sim | Idade. 15 a 45 |
| `pe` | texto | não | Pé bom: D (direito), E (esquerdo), A (ambos). `D`, `E`, `A` |
| `numero` | número inteiro | não | Número da camisa, único no elenco. 1 a 99 |
| `nacionalidade` | texto | não | Código da nacionalidade (ex.: br, ar, gb-eng). Padrão: br |
| `TEC` | número inteiro | não | Técnica (jogador de linha). 1 a 99 |
| `ATA` | número inteiro | não | Ataque (jogador de linha). 1 a 99 |
| `DEF` | número inteiro | não | Defesa (jogador de linha). 1 a 99 |
| `FIS` | número inteiro | não | Físico (jogador de linha). 1 a 99 |
| `MEN` | número inteiro | não | Mental (todos). 1 a 99 |
| `REF` | número inteiro | não | Reflexo (goleiro). 1 a 99 |
| `POS` | número inteiro | não | Posicionamento (goleiro). 1 a 99 |
| `AER` | número inteiro | não | Jogo aéreo (goleiro). 1 a 99 |
| `SAI` | número inteiro | não | Saída do gol (goleiro). 1 a 99 |
| `TAL` | número inteiro | não | Talento: quanto ainda pode evoluir. 1 a 99 |
| `fimContrato` | número inteiro | não | Último ano do contrato; sem ele, o jogo sorteia. 2027 a 2031 |

### `data/clubs/{id}.json → juniores[]`

Cada júnior. A promoção gera os atributos pelo potencial e pelo desenvolvimento.

| Campo | Tipo | Obrigatório | Valores |
|---|---|---|---|
| `nome` | texto | sim | Nome do júnior |
| `posicao` | texto | sim | Mesmas posições do jogador. `G`, `Z`, `LE`, `LD`, `V`, `M`, `PE`, `PD`, `CA` |
| `idade` | número inteiro | sim | Idade. 14 a 18 |
| `pe` | texto | não | Pé bom. `D`, `E`, `A` |
| `nacionalidade` | texto | não | Código da nacionalidade |
| `potencial` | número inteiro | não | Força que pode alcançar. 35 a 99 |
| `talento` | número inteiro | não | Talento. 35 a 99 |
| `desenvolvimento` | número inteiro | não | Quanto já evoluiu. 0 a 100 |

### `data/coaches.json`

Técnicos sem clube (os de clube ficam em "tecnico" no arquivo do clube).

Formato: `{ "coaches": [ ... ] }`.

| Campo | Tipo | Obrigatório | Valores |
|---|---|---|---|
| `id` | texto | sim | Identificador único (letras minúsculas, números, _ ou -) |
| `nome` | texto | sim | Nome do técnico |
| `idade` | número inteiro | não | Idade. 25 a 120 |
| `nacionalidade` | texto | não | Código da nacionalidade |
| `reputacao` | número | não | Reputação. 0 a 100 |
| `team_id` | texto | não | Vazio: técnico sem clube |

### `data/stadiums.json`

Estádios. Um estádio pode ser de vários clubes. A foto é images/stadiums/{image}.

Formato: `{ "stadiums": [ ... ] }`.

| Campo | Tipo | Obrigatório | Valores |
|---|---|---|---|
| `id` | texto | sim | Identificador do estádio |
| `nome` | texto | sim | Nome do estádio |
| `capacidade` | número inteiro | não | Lugares. 1000 a 200000 |
| `cidade` | texto | não | Cidade |
| `image` | texto | não | Arquivo da foto em images/stadiums |

### `data/competitions.json` (opcional)

Competições além das nacionais automáticas (estaduais, continentais, copas próprias). Sem "phases", o jogo monta o formato pelo tipo; o editor de competições configura o resto.

Formato: `{ "competitions": [ ... ] }`.

| Campo | Tipo | Obrigatório | Valores |
|---|---|---|---|
| `id` | texto | sim | Identificador da competição |
| `name` | texto | sim | Nome |
| `format` | texto | sim | pontos-corridos (liga), mata-mata ou grupos (copa com grupos). `pontos-corridos`, `mata-mata`, `grupos` |
| `scope` | texto | sim | Quem participa. `nacional`, `estadual`, `continental`, `mundial` |
| `country_id` | texto | sim | País (sede, nas continentais) |
| `teams` | lista | sim | Ids dos clubes inscritos (na 1ª temporada, se houver entry_rules) |
| `entry_rules` | lista | não | Quem entra na temporada seguinte: [{source, take: champion | runner_up | top, count, start, phase}]. source é o id de uma competição, ou rank:league / rank:cup com rank_start e rank_end (ligas ou copas nessa faixa do ranking de ligas). start é a 1ª posição da faixa (padrão 1); phase é o id da preliminar em que os clubes entram (vazio = fase principal). Ex.: supercopa = campeão da copa e campeão da liga |
| `same_season` | sim/não | não | true = as entry_rules valem nesta temporada: a competição nasce quando as competições de origem terminam (ex.: playoff entre divisões) |
| `champion_division` | texto | não | Com same_season: id da divisão que o campeão joga na temporada seguinte (os demais vão para others_division) |
| `others_division` | texto | não | Com same_season: id da divisão dos demais participantes na temporada seguinte |
| `ranking_countries` | lista | não | Ids dos países que contam no ranking das regras rank:league e rank:cup (vazio = todos) |
| `draft` | sim/não | não | Rascunho: incompleta, fica fora das carreiras até sair do rascunho |
| `participants` | texto | não | Como o editor monta quem participa: fixed (clubes escolhidos), results (entry_rules) ou champions (entry_sources). O jogo não usa. `fixed`, `results`, `champions` |
| `num_rounds` | número inteiro | não | Liga: 1 = turno único, 2 = ida e volta. 1 a 2 |
| `logo_image` | texto | não | Arquivo do logo em images/competitions |
| `trophy_image` | texto | não | Arquivo do troféu em images/trophies |

### `data/nationalities.json` (opcional)

Nacionalidades novas; o mesmo código troca o nome de uma do jogo. A bandeira é images/flags/{code}.png.

Formato: `{ "nationalities": [ ... ] }`.

| Campo | Tipo | Obrigatório | Valores |
|---|---|---|---|
| `code` | texto | sim | Código: 2 a 8 letras minúsculas, hífen permitido |
| `name` | texto | sim | Nome |

### `data/names/{code}.json` (opcional)

Nomes para gerar jogadores e técnicos daquela nacionalidade (no lugar dos do jogo).

| Campo | Tipo | Obrigatório | Valores |
|---|---|---|---|
| `country` | texto | sim | Código da nacionalidade (igual ao nome do arquivo) |
| `first_names` | lista | sim | Nomes |
| `second_names` | lista | não | Segundos nomes |
| `last_names` | lista | não | Sobrenomes |
| `nicknames` | lista | não | Apelidos |
| `second_name_chance` | número | sim | Chance de segundo nome. 0 a 1 |
| `last_name_chance` | número | sim | Chance de sobrenome. 0 a 1 |
| `nickname_chance` | número | sim | Chance de apelido no lugar do nome. 0 a 1 |

## Exemplo mínimo

`data/countries.json`: um país com uma divisão de 4 clubes.

```json
{
  "countries": [
    {
      "id": "pais_exemplo",
      "name": "País Exemplo",
      "iso2": "br",
      "confederation": "CONMEBOL",
      "division_sizes": [
        4
      ]
    }
  ]
}
```

`data/clubs/clube_azul.json`: um clube com técnico e três jogadores (um elenco de verdade tem uns 30). Faça mais três clubes iguais para completar a divisão.

```json
{
  "id": "clube_azul",
  "nome": "Clube Azul",
  "country_id": "pais_exemplo",
  "corPrimaria": "#1f4fbf",
  "corSecundaria": "#ffffff",
  "reputacao": 60,
  "elo": 650,
  "tecnico": {
    "id": "tecnico_clube_azul",
    "nome": "João Pereira",
    "idade": 48,
    "nacionalidade": "br",
    "reputacao": 55
  },
  "jogadores": [
    {
      "nome": "Marcos Lima",
      "posicao": "G",
      "idade": 29,
      "pe": "D",
      "numero": 1,
      "REF": 68,
      "POS": 66,
      "AER": 64,
      "SAI": 62,
      "MEN": 65,
      "TAL": 60
    },
    {
      "nome": "Rafael Souza",
      "posicao": "Z",
      "idade": 26,
      "pe": "D",
      "numero": 4,
      "TEC": 55,
      "ATA": 40,
      "DEF": 70,
      "FIS": 68,
      "MEN": 62,
      "TAL": 64
    },
    {
      "nome": "Bruno Alves",
      "posicao": "CA",
      "idade": 24,
      "pe": "E",
      "numero": 9,
      "TEC": 66,
      "ATA": 72,
      "DEF": 35,
      "FIS": 64,
      "MEN": 60,
      "TAL": 70
    }
  ],
  "juniores": []
}
```

## Passo a passo

1. No editor do Gofoot, crie um patch (modelo Em branco, Exemplo ou Liga nacional) e use "Abrir pasta" na aba Patch.
2. Na aba Patch, "Copiar instruções para IA" copia este guia com o resumo do seu patch. Cole na IA e peça o que quiser (ex.: "crie os 20 clubes da liga japonesa com elencos de 30 jogadores").
3. Salve os arquivos que a IA gerar dentro da pasta, nos caminhos acima.
4. Volte ao jogo: o editor recarrega o patch sozinho. A seção "Saúde do patch" aponta o que corrigir, com arquivo e item.
5. Imagens: escudos em `images/clubs/{id do clube}.png`, bandeiras em `images/flags/`, logos em `images/competitions/`. Sem imagem, o jogo usa um escudo nas cores do clube.
6. Ajuste pontual sem sair do jogo: a aba JSON do editor (ou o botão { } de cada item) edita um time, jogador, competição, técnico, país, estádio ou nacionalidade. O editor confere os campos acima enquanto você digita.

A pasta `schema/` tem os mesmos campos em JSON Schema, para ferramentas que validam JSON.
